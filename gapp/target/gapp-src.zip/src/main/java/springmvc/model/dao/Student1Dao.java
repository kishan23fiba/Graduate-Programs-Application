package springmvc.model.dao;
import java.util.List;

import springmvc.model.Application;
import springmvc.model.Student;
public interface Student1Dao {

	List<Application> getApplications();
}
