package springmvc.model.dao;

import java.util.List;

import springmvc.model.Department;
import springmvc.model.Users;

public interface DepartmentDao {

    List<Department> getDepartments();
    Department saveDepartment(Department department);
    Department getDepartment(Integer id);
    
}
