package springmvc.model.dao;

import java.util.List;

import springmvc.model.Users;

public interface UsersDao {
	List<Users> getUsers();
	Users saveUser(Users user);
	Users getUser(Integer id);
}
