package springmvc.model.dao;
import java.util.List;

import springmvc.model.Application;
public interface AccountingApplicationDao {

	List<Application> getApplications();
}
