package springmvc.model.dao;

import springmvc.model.AcademicRecords;

public interface AcademicRecordsDao {
	AcademicRecords getAcademicRecord(Integer sid);
	AcademicRecords saveAcademicRecord(AcademicRecords academicRecords);

}
