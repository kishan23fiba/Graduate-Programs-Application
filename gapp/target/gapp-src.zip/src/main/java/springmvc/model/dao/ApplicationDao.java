package springmvc.model.dao;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import springmvc.model.Application;
import springmvc.model.Department;

public interface ApplicationDao {
	//List<Application> getStudApplications(Integer id);
	Application getStudentApplication(Integer sid);
	Application getApplication(Integer id);
    public Application saveApplication(Application application);
    Integer getLastID();
}
